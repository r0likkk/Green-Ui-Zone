local currentZoneType = nil
print(" Client side of script, by rolikk loaded. If you have any questions, ask me on discord: .rxnlol or my website: https://rolikk.space/")
function isPlayerInZone(zone)
    local ped = PlayerPedId()
    local px, py, pz = table.unpack(GetEntityCoords(ped))
    local dist = #(vector3(zone.x, zone.y, zone.z) - vector3(px, py, pz))
    return dist <= zone.radius
end

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(350)
        local foundZoneType = nil
        for _,zone in ipairs(Config.GreenZones) do
            if isPlayerInZone(zone) then
                foundZoneType = zone.type
                break
            end
        end

        if not foundZoneType then
            for _,zone in ipairs(Config.RedZones) do
                if isPlayerInZone(zone) then
                    foundZoneType = zone.type
                    break
                end
            end
        end

        if not foundZoneType then
            for _,zone in ipairs(Config.EventZones) do
                if isPlayerInZone(zone) then
                    foundZoneType = zone.type
                    break
                end
            end
        end

        if foundZoneType ~= currentZoneType then
            currentZoneType = foundZoneType
            if currentZoneType == "green" or currentZoneType == "red" or currentZoneType == "event" then
                SendNUIMessage({action = "show", zoneType = currentZoneType})
                SetNuiFocus(false, false)
            else
                SendNUIMessage({action = "hide"})
            end
        end
    end
end)