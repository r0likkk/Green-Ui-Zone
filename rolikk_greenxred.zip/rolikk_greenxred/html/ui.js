//if u dont know how to use this, ask me on discord: .rxnlol
window.addEventListener('message', function(event) {
    if (event.data.action === 'show') {
        document.getElementById('zone-ui').style.display = 'block';
        if (event.data.zoneType === 'green') {
            document.getElementById('zone-green').style.display = 'flex';
            document.getElementById('zone-red').style.display = 'none';
            document.getElementById('zone-event').style.display = 'none';
        } else if (event.data.zoneType === 'red') {
            document.getElementById('zone-green').style.display = 'none';
            document.getElementById('zone-red').style.display = 'flex';
            document.getElementById('zone-event').style.display = 'none';
        } else if (event.data.zoneType === 'event') {
            document.getElementById('zone-green').style.display = 'none';
            document.getElementById('zone-red').style.display = 'none';
            document.getElementById('zone-event').style.display = 'flex';
        }
    } else if (event.data.action === 'hide') {
        document.getElementById('zone-ui').style.display = 'none';
        document.getElementById('zone-green').style.display = 'none';
        document.getElementById('zone-red').style.display = 'none';
        document.getElementById('zone-event').style.display = 'none';
    }
});