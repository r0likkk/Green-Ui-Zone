
fx_version 'bodacious'
game 'gta5'

author 'rolikk'
version '1.0.0'
description 'https://rolikk.space/'
shared_script 'config.lua'
client_script 'client.lua'

ui_page 'html/index.html'

files {
    'config.lua',
    'client.lua',
    'html/index.html',
    'html/style.css',
    'html/ui.js',
    'html/shield.svg',
    'html/crosshair.svg'
}