Config = {}

Config.GreenZones = {
    {type = 'green', x=-531.1533, y=-228.2424, z=36.6972, radius=40.0}, -- spawn
    {type = 'green', x=4891.4663, y=-5736.5308, z=26.3509, radius=15.0}, -- cayo
    {type = 'green', x=-765.4736, y=5535.5322, z=33.4834, radius=15.0}, -- pila
}

Config.RedZones = {
    {type = 'red', x = -555.0225, y = 5324.6343, z = 73.5997, radius = 95.0}, -- pila
    {type = 'red', x = 5011.7012, y = -5748.8145, z = 32.8526, radius = 85.0}, -- cayo
    {type = 'red', x = 2942.2573, y = 2791.6196, z = 40.3656, radius = 235.0}, -- FRN BLACK
    {type = 'red', x = 254.0824, y = 225.1338, z = 101.8758, radius = 235.0}, -- FRN BLACK
}

Config.EventZones = {
    {name = "Event Zóna", x = 610.7225, y = 662.6240, z = 129.3436, radius = 60.0, type = "event"}
} 